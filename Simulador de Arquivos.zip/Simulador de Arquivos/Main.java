import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Iniciando simulador de arquivos...");
        try {
            FileSystemSimulator simulator = new FileSystemSimulator();
            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                System.out.println("\n=== Menu do Simulador ===");
                System.out.println("1. Criar arquivo");
                System.out.println("2. Listar arquivos/diretório");
                System.out.println("3. Deletar arquivo");
                System.out.println("4. Ver transações");
                System.out.println("5. Sair");
                System.out.println("6. Ver conteúdo de arquivo");
                System.out.println("7. Editar arquivo (sobrescrever / acrescentar)");
                System.out.println("8. Mover conteúdo entre arquivos");
                System.out.println("9. Copiar arquivo");
                System.out.println("10. Renomear/Movimentar arquivo");
                System.out.println("11. Criar diretório");
                System.out.println("12. Deletar diretório (recursivo)");
                System.out.println("13. Renomear/Movimentar diretório");
                System.out.print("Escolha uma opção: ");

                String line = scanner.nextLine().trim();
                int option;
                try {
                    option = Integer.parseInt(line);
                } catch (NumberFormatException ex) {
                    System.out.println("Entrada inválida.");
                    continue;
                }

                switch (option) {
                    case 1 -> {
                        System.out.print("Caminho do arquivo (ex: dir/sub/meu.txt): ");
                        String filename = scanner.nextLine().trim();
                        System.out.print("Adicionar conteúdo inicial? (s/n): ");
                        String yn = scanner.nextLine().trim().toLowerCase();
                        if (yn.equals("s")) {
                            System.out.print("Conteúdo (uma linha): ");
                            String content = scanner.nextLine();
                            simulator.createFile(filename, content);
                        } else {
                            simulator.createFile(filename);
                        }
                    }
                    case 2 -> {
                        System.out.print("Caminho do diretório (ou vazio para /): ");
                        String dir = scanner.nextLine().trim();
                        simulator.listFiles(dir);
                    }
                    case 3 -> {
                        System.out.print("Caminho do arquivo: ");
                        String toDelete = scanner.nextLine().trim();
                        simulator.deleteFile(toDelete);
                    }
                    case 4 -> simulator.showTransactions();
                    case 5 -> {
                        running = false;
                        System.out.println("Encerrando simulador...");
                    }
                    case 6 -> {
                        System.out.print("Caminho do arquivo: ");
                        String toRead = scanner.nextLine().trim();
                        String content = simulator.readFile(toRead);
                        if (content != null) {
                            System.out.println("\n--- Conteúdo de " + toRead + " ---");
                            System.out.println(content);
                            System.out.println("--- fim ---");
                        }
                    }
                    case 7 -> {
                        System.out.print("Caminho do arquivo: ");
                        String toEdit = scanner.nextLine().trim();
                        System.out.print("Sobrescrever ou acrescentar? (s= sobrescrever / a= acrescentar): ");
                        String mode = scanner.nextLine().trim().toLowerCase();
                        boolean overwrite = mode.equals("s");
                        System.out.print("Conteúdo a escrever (uma linha): ");
                        String newContent = scanner.nextLine();
                        simulator.writeFile(toEdit, newContent, overwrite);
                    }
                    case 8 -> {
                        System.out.print("Arquivo origem: ");
                        String src = scanner.nextLine().trim();
                        System.out.print("Arquivo destino: ");
                        String dst = scanner.nextLine().trim();
                        System.out.print("Quantidade de caracteres a mover (0 = mover tudo): ");
                        String cntStr = scanner.nextLine().trim();
                        int cnt = 0;
                        try { cnt = Integer.parseInt(cntStr); } catch (NumberFormatException ex) { cnt = 0; }
                        simulator.moveContent(src, dst, cnt);
                    }
                    case 9 -> {
                        System.out.print("Arquivo origem: ");
                        String s = scanner.nextLine().trim();
                        System.out.print("Destino (arquivo ou diretório): ");
                        String d = scanner.nextLine().trim();
                        simulator.copyFile(s, d);
                    }
                    case 10 -> {
                        System.out.print("Arquivo origem: ");
                        String s = scanner.nextLine().trim();
                        System.out.print("Novo caminho/nome: ");
                        String d = scanner.nextLine().trim();
                        simulator.renameFile(s, d);
                    }
                    case 11 -> {
                        System.out.print("Caminho do diretório a criar: ");
                        String dir = scanner.nextLine().trim();
                        simulator.createDirectory(dir);
                    }
                    case 12 -> {
                        System.out.print("Caminho do diretório a deletar: ");
                        String dir = scanner.nextLine().trim();
                        simulator.deleteDirectory(dir);
                    }
                    case 13 -> {
                        System.out.print("Diretório origem: ");
                        String sdir = scanner.nextLine().trim();
                        System.out.print("Novo caminho/nome do diretório: ");
                        String ddir = scanner.nextLine().trim();
                        simulator.renameDirectory(sdir, ddir);
                    }
                    default -> System.out.println("Opção inválida!");
                }
            }
            scanner.close();
        } catch (Exception e) {
            System.err.println("Erro ao iniciar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}